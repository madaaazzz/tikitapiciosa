# Chiquita 💝

Este es un regalo especial.  
Para verlo en línea usando **GitHub Pages**, solo activa Pages en la configuración del repositorio y selecciona la rama principal.

Una vez publicado, podrás acceder a:
```
https://<tu-usuario>.github.io/<nombre-del-repo>/
```

---
> Subido con cariño 💌
